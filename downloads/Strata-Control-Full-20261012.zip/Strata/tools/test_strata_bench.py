"""Tests for tools/strata_bench.py with a fake engine behind a real HTTP server: the suite runner, the redaction, the report
writing and the comparison.  Light: no GPU, no Strata server, a few seconds."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import unittest
from unittest import mock
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import strata_bench as B  # noqa: E402


def text_of(messages) -> str:
    return "".join(m.get("content") or "" for m in messages)


class FakeStrata(ThreadingHTTPServer):
    """Speaks the parts of the Strata API the benchmark reads.  The conversation cache is the longest common prefix with the
    previous prompt (4 characters = 1 token)."""
    daemon_threads = True

    def __init__(self, ctx=32768, fail_after=None):
        super().__init__(("127.0.0.1", 0), Handler)
        self.ctx, self.prev, self.requests, self.fail_after = ctx, "", 0, fail_after
        self.lock = threading.Lock()
        threading.Thread(target=self.serve_forever, daemon=True).start()

    def stop(self):
        self.shutdown()
        self.server_close()

    @property
    def base(self):
        return f"http://127.0.0.1:{self.server_address[1]}"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        s = self.server
        if self.path == "/health":
            self.send_json({"status": "ok", "service": "strata", "loaded": True})
        elif self.path == "/v1/models":
            self.send_json({"object": "list", "data": [{"id": "fake", "meta": {"n_ctx": s.ctx}}]})
        elif self.path == "/props":
            self.send_json({"total_slots": 4, "model_alias": "fake-model", "build_info": "Strata 9.9.9"})
        elif self.path == "/v1/status":
            self.send_json({"machine": {"gpu": {"name": "NVIDIA GeForce RTX 9999", "total_mib": 12288}, "ram": {"total_gib": 64.0}},
                            "engine": "9.9.9", "vram": {"free_mib": 1000}})
        elif self.path == "/metrics":
            self.send_json({"engine": {"version": "9.9.9", "max_context": s.ctx, "model_path": r"C:\Users\Someone\models\x.gguf"},
                            "hardware_static": {"gpu_name": "NVIDIA GeForce RTX 9999", "cpu_name": "Fake CPU 9", "cores": 8, "threads": 16}})
        else:
            self.send_json({}, 404)

    def do_POST(self):
        s = self.server
        req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        text = text_of(req["messages"])
        with s.lock:
            s.requests += 1
            n = s.requests
            common = 0
            for x, y in zip(s.prev, text):
                if x != y:
                    break
                common += 1
            s.prev = text
        if s.fail_after is not None and n > s.fail_after:
            self.send_json({"error": "boom"}, 500)
            return
        prompt = max(1, len(text) // 4)
        cached = min(prompt, common // 4)
        gen = min(req.get("max_tokens", 16), 12)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()

        def chunk(delta, finish=None, **extra):
            d = {"id": "x", "choices": [{"index": 0, "delta": delta, "finish_reason": finish}], **extra}
            self.wfile.write(b"data: " + json.dumps(d).encode() + b"\n\n")
            self.wfile.flush()
        chunk({"role": "assistant"})
        for _ in range(gen):
            chunk({"content": "word "})
        chunk({}, "stop", usage={"prompt_tokens": prompt, "completion_tokens": gen, "total_tokens": prompt + gen,
                                 "prompt_tokens_details": {"cached_tokens": cached}},
              timings={"cache_n": cached, "prompt_n": prompt - cached, "prompt_ms": 100.0,
                       "prompt_per_second": 1000.0 + n, "predicted_n": gen, "predicted_ms": 200.0, "predicted_per_second": 60.0})
        self.wfile.write(b"data: [DONE]\n\n")


class SuiteTests(unittest.TestCase):
    def setUp(self):
        self.srv = FakeStrata()
        self.addCleanup(self.srv.stop)

    def suite(self, **kw):
        return B.Suite(self.srv.base, "", kw.pop("ctx", 32768), kw.pop("runs", 3), False, log=lambda *a: None, **kw)

    def test_full_suite_shapes_and_medians(self):
        out = self.suite(want_clients=3).run()
        self.assertEqual(out["failures"], [])
        self.assertEqual(out["chat"]["decode_tps"]["median"], 60.0)
        self.assertEqual(out["chat"]["decode_tps"]["n"], 9)                 # 3 questions x 3 runs
        self.assertEqual(set(out["prompts"]), {"4K", "16K"})
        for v in out["prompts"].values():
            self.assertEqual(v["prompt_tps"]["n"], 3)
            self.assertLess(v["reused_tokens"]["median"], v["prompt_tokens"]["median"] / 100)   # a fresh tag at the start: next to nothing reused
        p4, p16 = (out["prompts"][k]["prompt_tokens"]["median"] for k in ("4K", "16K"))
        self.assertAlmostEqual(p16 / p4, 4, delta=0.6)                      # the sizes are calibrated, not guessed
        self.assertEqual(out["clients"]["clients"], 3)
        self.assertEqual(out["clients"]["errors"], 0)
        self.assertEqual(out["clients"]["rounds"][0]["tokens"], 3 * 12)

    def test_agent_session_reuses_the_conversation(self):
        out = self.suite(runs=2).run()
        ag = out["agent"]
        self.assertEqual(len(ag["sessions"]), 2)
        turns = ag["sessions"][0]
        self.assertEqual([t["turn"] for t in turns], list(range(B.AGENT_TURNS + 1)))
        self.assertEqual(turns[0]["reused_tokens"], 0)
        for t in turns[1:]:
            self.assertGreater(t["reused_tokens"], 0)
            self.assertLess(t["read_tokens"], t["prompt_tokens"])
        self.assertGreater(ag["hit_pct"]["median"], 50)
        self.assertLess(ag["reread_tokens"]["median"], ag["new_tokens"]["median"])      # new file text dominates, not re-reading
        self.assertGreater(turns[-1]["prompt_tokens"], turns[1]["prompt_tokens"])    # the conversation grows

    def test_small_context_skips_the_long_prompts(self):
        self.srv.ctx = 8192
        out = self.suite(ctx=8192, runs=1, want_long=True).run()
        self.assertIn("4K", out["prompts"])
        self.assertEqual(set(out["skipped"]), {"16K", "32K", "agent"})
        self.assertIn("below ~10K", out["skipped"]["agent"])
        self.assertEqual(out["agent"], {})                                  # no request was sent for the agent session

    def test_agent_runs_when_the_context_fits_it(self):
        out = self.suite(ctx=16384, runs=1).run()
        self.assertNotIn("agent", out["skipped"])
        self.assertTrue(out["agent"]["sessions"])

    def test_failures_are_reported_not_hidden(self):
        self.srv.fail_after = 3                  # warm-up and calibration succeed, then every request fails
        out = self.suite(runs=1).run()
        self.assertTrue(out["failures"])
        self.assertTrue(all("HTTP 500" in f["error"] for f in out["failures"]))
        self.assertIsNone(out["chat"]["decode_tps"])


class RedactionTests(unittest.TestCase):
    def test_paths_names_ips_and_keys(self):
        red = B.redactor(extra=["Jane Roe Laptop"], key="sk-secret-123456")
        user = os.environ.get("USERNAME") or os.environ.get("USER") or "tester"
        cases = [r"C:\Users\someone_else\models\a.gguf", "/home/bob/strata/x.json", "/Users/alice/Library",
                 "peer 192.168.1.20 and 10.0.0.7 and 100.101.102.103", "Authorization: Bearer abcdefghijkl12345",
                 "key sk-secret-123456 here", "name Jane Roe Laptop"]
        text = red("\n".join(cases))
        for s in ("someone_else", "bob", "alice", "192.168.1.20", "10.0.0.7", "100.101.102.103", "abcdefghijkl12345",
                  "sk-secret-123456", "Jane Roe Laptop"):
            self.assertNotIn(s, text)
        self.assertIn("<user>", text)
        self.assertIn("<ip>", text)
        self.assertEqual(red("127.0.0.1:8080 and version 0.1.40.3 and driver 32.0.15.7"), "127.0.0.1:8080 and version 0.1.40.3 and driver 32.0.15.7")
        self.assertNotIn(str(B.ROOT), red(f"loading {B.ROOT / 'strata-x.json'}"))
        self.assertIn("<strata>", red(f"loading {B.ROOT / 'strata-x.json'}"))
        self.assertNotIn(str(Path.home()), red(f"in {Path.home() / 'data'}"))
        if len(user) >= 4:
            self.assertNotIn(user, red(f"hello {user} world"))

    def test_objects_are_redacted_deeply(self):
        red = B.redactor()
        out = B.redact_obj({"a": [{"p": r"D:\Users\zed\x"}], "n": 3}, red)
        self.assertNotIn("zed", json.dumps(out))
        self.assertEqual(out["n"], 3)

    def test_config_view_drops_secrets_and_cuts_paths(self):
        cfg = {"exe": r"C:\Users\me\Strata\engine\strata.exe", "args": ["--native", "/home/me/models/m-IQ3_XXS.gguf", "--ctx", "65536"],
               "api_key": "hunter2", "model_name": "Fake Model", "log": "/tmp/x.log", "port": 8080,
               "env": {"STRATA_FOO": "/home/me/z", "PATH": "/usr/bin", "STRATA_TOKEN": "t"}}
        v = B.config_view(cfg)
        self.assertEqual(v["exe"], "strata.exe")
        self.assertEqual(v["args"], ["--native", "m-IQ3_XXS.gguf", "--ctx", "65536"])
        self.assertNotIn("api_key", v)
        self.assertNotIn("log", v)
        self.assertEqual(v["env"], {"STRATA_FOO": "z"})
        self.assertEqual(B.detect_quant(v), "IQ3_XXS")
        self.assertNotIn("hunter2", json.dumps(v))


class ReportTests(unittest.TestCase):
    def setUp(self):
        p = mock.patch.object(B, "gpu_info_local", return_value={"gpus": []})     # the server's own GPU name, not this PC's
        p.start()
        self.addCleanup(p.stop)

    def run_main(self, srv, out_dir, *extra):
        argv = ["--url", srv.base, "--out", out_dir, "--runs", "2", "--quiet", *extra]
        return B.main(argv)

    def test_main_writes_a_redacted_report(self):
        srv = FakeStrata()
        self.addCleanup(srv.stop)
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(self.run_main(srv, d, "--clients", "2"), 0)
            dirs = list(Path(d).iterdir())
            self.assertEqual(len(dirs), 1)
            name = dirs[0].name
            self.assertRegex(name, r"^\d{4}-\d\d-\d\d-community-rtx-9999")
            readme = (dirs[0] / "README.md").read_text(encoding="utf-8")
            for part in ("# Community benchmark on NVIDIA GeForce RTX 9999", "## Hardware and software", "## Model and configuration",
                         "## Method", "## Results", "## Correctness and limitations", "### Agent session", "### Concurrency: 2 clients",
                         "| Configuration | Actual prompt tokens | Reused tokens |"):
                self.assertIn(part, readme)
            raw = json.loads((dirs[0] / "results.json").read_text(encoding="utf-8"))
            self.assertEqual(raw["schema"], B.SCHEMA)
            self.assertEqual(raw["machine"]["engine_version"], "9.9.9")
            self.assertEqual(raw["results"]["chat"]["decode_tps"]["median"], 60.0)
            blob = readme + json.dumps(raw)
            self.assertNotIn("Someone", blob)                    # the engine's model_path never reaches the report
            # a second run the same day does not overwrite the first
            self.assertEqual(self.run_main(srv, d), 0)
            self.assertEqual(len(list(Path(d).iterdir())), 2)

    def test_compare(self):
        srv = FakeStrata()
        self.addCleanup(srv.stop)
        with tempfile.TemporaryDirectory() as d:
            self.run_main(srv, d)
            old = next(Path(d).iterdir())
            data = json.loads((old / "results.json").read_text(encoding="utf-8"))
            data["results"]["chat"]["decode_tps"]["median"] = 30.0
            data["machine"]["engine_version"] = "1.0"
            (old / "results.json").write_text(json.dumps(data), encoding="utf-8")
            self.run_main(srv, d)
            new = max(Path(d).iterdir(), key=lambda p: p.name)
            table = B.compare_table(B.load_results(old), B.load_results(new))
            self.assertIn("chat decode tok/s", table)
            self.assertIn("+100.0%", table)
            self.assertIn("engine: 1.0 -> 9.9.9", table)

    def test_names(self):
        m = {"gpu": ["NVIDIA GeForce RTX 3060"], "model": "Qwen3.8 Flash-Next", "quant": "IQ3_XXS"}
        self.assertEqual(B.results_dir_name(m, "2026-10-10"), "2026-10-10-community-rtx-3060-qwen3-8-flash-next-iq3-xxs")
        m["model"] = "qwen-iq3_xxs"                                      # a quant already in the name is not added twice
        self.assertEqual(B.results_dir_name(m, "2026-10-10"), "2026-10-10-community-rtx-3060-qwen-iq3-xxs")
        self.assertEqual(B.gpu_slug({"gpu": ["A B 4090", "A B 4090"]}), "2x-a-b-4090")
        m["model"] = "qwen-iq3_xxs"                                      # a quant already in the name is not added twice
        self.assertEqual(B.results_dir_name(m, "2026-10-10"), "2026-10-10-community-rtx-3060-qwen-iq3-xxs")
        self.assertEqual(B.gpu_slug({"gpu": []}), "cpu")

    def test_no_server_is_an_error_not_a_crash(self):
        self.assertEqual(B.main(["--url", "http://127.0.0.1:9", "--quiet"]), 2)


if __name__ == "__main__":
    unittest.main()
