@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Strata\.venv\Scripts\pythonw.exe" goto install
dir /b "%~dp0Strata\strata-*.json" >nul 2>nul
if errorlevel 1 goto install
call "%~dp0Strata\STRATA-CONTROL.bat"
exit /b
:install
call "%~dp0INSTALL.bat" %*