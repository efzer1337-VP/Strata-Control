$ErrorActionPreference = 'Stop'
$taskTarget = Join-Path $PSScriptRoot 'START-CONTROL.bat'
$taskDesktop = [Environment]::GetFolderPath('Desktop')
$taskShell = New-Object -ComObject WScript.Shell
$taskLink = Join-Path $taskDesktop 'Strata Control.lnk'
if (Test-Path -LiteralPath $taskLink) {
    $taskOld = $taskShell.CreateShortcut($taskLink)
    if ($taskOld.TargetPath -ne $taskTarget) {
        $taskLink = Join-Path $taskDesktop 'Strata Full Control.lnk'
    }
}
$taskNew = $taskShell.CreateShortcut($taskLink)
$taskNew.TargetPath = $taskTarget
$taskNew.WorkingDirectory = $PSScriptRoot
$taskNew.Description = 'Strata + Control'
$taskNew.Save()