@echo off
if not exist "%~dp0Strata\.venv\Scripts\python.exe" goto install
call "%~dp0Strata\STRATA-CONTROL.bat" %*
exit /b
:install
call "%~dp0INSTALL.bat" %*
