@echo off
call "%~dp0Strata\INSTALL.bat" %*
exit /b %errorlevel%
