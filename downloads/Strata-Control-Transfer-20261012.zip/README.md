# Strata Control for Windows

A Windows control window for Strata with an Evergreen-inspired dark theme.

## Installation / Установка

1. Install Strata from https://github.com/Niko1221/Strata using its START-HERE.bat and docs/AI_SETUP.md.
2. Copy strata_control.py and STRATA-CONTROL.bat from this package into the Strata folder, beside START-HERE.bat.
3. Run STRATA-CONTROL.bat. Select a generated strata-*.json model profile.

Модель, mmproj, движок и Python-окружение устанавливаются отдельно процедурой Strata. Переносимые файлы приложения не содержат конфигурацию конкретного ПК.

## Управление

Запуск, остановка и перезапуск сервера, сохранение профиля, переход к веб-интерфейсу, журнал. Контекст, KV-кэш, resident KV, spec decoding, expert cache, vision и дополнительные аргументы редактируются в окне.

## Память ПК

На вкладке «Память ПК» задаётся запас VRAM и RAM в ГБ (1 ГБ = 1024 МиБ).

- VRAM: передаёт --vram-reserve-mib. Для резерва требуется Expert cache = auto. Это цель выбора размера кэша при запуске, а не строгий лимит общего потребления видеопамяти.
- RAM: включает --resident-budget-gib и STRATA_RESIDENT_HEADROOM_GIB. Эксперты сверх бюджета читаются с диска, что может снизить скорость.
- При запуске через это приложение отдельный наблюдатель проверяет свободную RAM каждые 0,5 секунды. Три проверки ниже резерва подряд останавливают только запущенный экземпляр сервера. Причина записывается в журнал, а окно показывает остановку защитой RAM.
- Наблюдатель продолжает работать после закрытия окна. RAM = 0 отключает управление резервом и наблюдатель. Запуск через штатный run-*.bat не включает эту защиту приложения.
- Эти настройки не гарантируют отсутствие сбоев драйвера GPU или зависаний по другим причинам.

Изменения применяются при следующем запуске или перезапуске через Strata Control. Профиль сохраняется локально, с резервной копией при первом сохранении.
