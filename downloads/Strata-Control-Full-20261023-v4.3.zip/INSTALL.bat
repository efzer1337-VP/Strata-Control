@echo off
setlocal
title Strata + Control - installation
cd /d "%~dp0"
if not exist "%~dp0Strata\START-HERE.bat" (
  echo Extract the entire package before running INSTALL.bat.
  pause
  exit /b 1
)
call "%~dp0Strata\START-HERE.bat" --setup --no-start %*
if errorlevel 1 exit /b 1
if not exist "%~dp0Strata\.venv\Scripts\python.exe" (
  echo Installation did not create the Python environment.
  pause
  exit /b 1
)
dir /b "%~dp0Strata\strata-*.json" >nul 2>nul
if errorlevel 1 (
  echo No model profile was created. Run INSTALL.bat again to finish setup.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE-SHORTCUT.ps1"
call "%~dp0START-CONTROL.bat"